@extends('web.layouts.app')
@section('content')
    <!-- breadcrumb area start -->
    <section class="breadcrumb__area  breadcrumb__pt-310 include-bg p-relative"
             data-background="/front/assets/img/breadcrum/ab-1.1.jpg">
        <div class="ac-about-shape-img z-index-1">
            <img src="/front/assets/img/breadcrum/ab-shape-1.1.jpg" alt="">
        </div>
        <div class="container">
            <div class="row">
                <div class="col-xxl-12">
                    <div class="breadcrumb__content p-relative z-index-1">
                        <h3 class="breadcrumb__title">Blog & Article</h3>
                        <a href="{{route('contact')}}" class="tp-btn-white-border">Lets work together <i class="far fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- breadcrumb area end -->


    <!-- postbox area start -->
    <div class="postbox__area pt-120 pb-120">
        <div class="container">
            <div class="row">
                <div class="col-xxl-12 col-xl-12 col-lg-12">
                    <div class="postbox__wrapper pr-20">
                        @foreach($blogs as $blog)
                        <article class="postbox__item format-image mb-50 transition-3">
                            <div class="postbox__thumb w-img">
                                <a href="{{route('singleBlog',$blog->id)}}">
                                    <img src="/front/assets/img/blog/{{$blog->image}}" alt="">
                                </a>
                            </div>
                            <div class="postbox__content">
                                <div class="postbox__meta">
                                    <span><a href="#"><i class="fal fa-user-circle"></i> Alextina </a></span>
                                    <span><a href="#"><i class="fal fa-clock"></i> Dec 28, 2022</a></span>
                                    <span><a href="#"><i class="fal fa-comment-alt-lines"></i>(04) Coments</a></span>
                                    <span><a href="#"><i class="fal fa-eye"></i> 1,526 views</a></span>
                                </div>
                                <h3 class="postbox__title">
                                    <a href="{{route('singleBlog',$blog->id)}}">{{$blog->title}}</a>
                                </h3>
                                <div class="postbox__text">
                                    <p>{{$blog->subtitle}}</p>
                                </div>
                                <div class="post__button">
                                    <a class="tp-btn-yellow" href="{{route('singleBlog',$blog->id)}}"> READ MORE</a>
                                </div>
                            </div>

                        </article>
                        @endforeach

                            {{$blogs->links("pagination::bootstrap-4")}}


{{--                        <div class="basic-pagination">--}}
{{--                            <nav>--}}
{{--                                <ul>--}}
{{--                                    <li>--}}
{{--                                        <a href="blog.html">--}}
{{--                                            <i class="far fa-angle-left"></i>--}}
{{--                                        </a>--}}
{{--                                    </li>--}}
{{--                                    <li>--}}
{{--                                        <a href="blog.html">1</a>--}}
{{--                                    </li>--}}
{{--                                    <li>--}}
{{--                                        <span class="current">2</span>--}}
{{--                                    </li>--}}
{{--                                    <li>--}}
{{--                                        <a href="blog.html">3</a>--}}
{{--                                    </li>--}}
{{--                                    <li>--}}
{{--                                        <a href="blog.html">--}}
{{--                                            <i class="far fa-angle-right"></i>--}}
{{--                                        </a>--}}
{{--                                    </li>--}}
{{--                                </ul>--}}
{{--                            </nav>--}}
{{--                        </div>--}}
                    </div>
                </div>
{{--                <div class="col-xxl-4 col-xl-4 col-lg-4">--}}
{{--                    <div class="sidebar__wrapper">--}}
{{--                        <div class="sidebar__widget mb-40">--}}
{{--                            <h3 class="sidebar__widget-title">Search Here</h3>--}}
{{--                            <div class="sidebar__widget-content">--}}
{{--                                <div class="sidebar__search">--}}
{{--                                    <form action="#">--}}
{{--                                        <div class="sidebar__search-input-2">--}}
{{--                                            <input type="text" placeholder="Search your keyword...">--}}
{{--                                            <button type="submit"><i class="far fa-search"></i></button>--}}
{{--                                        </div>--}}
{{--                                    </form>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                        <div class="sidebar__widget mb-40">--}}
{{--                            <h3 class="sidebar__widget-title">Categories</h3>--}}
{{--                            <div class="sidebar__widget-content">--}}
{{--                                <ul>--}}
{{--                                    <li><a href="blog.html">Web Design<span>26</span></a></li>--}}
{{--                                    <li><a href="blog.html">Devlopment <span>30</span></a></li>--}}
{{--                                    <li><a href="blog.html">Branding <span>71</span></a></li>--}}
{{--                                    <li><a href="blog.html">MOtion Design <span>56</span></a></li>--}}
{{--                                    <li><a href="blog.html">UI/UX Deisgn <span>60</span></a></li>--}}
{{--                                    <li><a href="blog.html">Graphic Design <span>99</span></a></li>--}}
{{--                                </ul>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                        <div class="sidebar__widget mb-40">--}}
{{--                            <h3 class="sidebar__widget-title">Pages</h3>--}}
{{--                            <div class="sidebar__widget-content">--}}
{{--                                <ul>--}}
{{--                                    <li><a href="blog.html">Web Design <span><i class="fal fa-angle-right"></i></span></a></li>--}}
{{--                                    <li><a href="blog.html">Devlopment <span><i class="fal fa-angle-right"></i></span></a></li>--}}
{{--                                    <li><a href="blog.html">Branding <span><i class="fal fa-angle-right"></i></span></a></li>--}}
{{--                                    <li><a href="blog.html">MOtion Design<span><i class="fal fa-angle-right"></i></span></a></li>--}}
{{--                                    <li><a href="blog.html">UI/UX Deisgn  <span><i class="fal fa-angle-right"></i></span></a></li>--}}
{{--                                    <li><a href="blog.html">Graphic Design  <span><i class="fal fa-angle-right"></i></span></a></li>--}}
{{--                                </ul>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                        <div class="sidebar__widget mb-40">--}}
{{--                            <h3 class="sidebar__widget-title">Recent Post</h3>--}}
{{--                            <div class="sidebar__widget-content">--}}
{{--                                <div class="sidebar__post rc__post">--}}
{{--                                    <div class="rc__post mb-20 d-flex align-items-center">--}}
{{--                                        <div class="rc__post-thumb mr-20">--}}
{{--                                            <a href="blog-details.html"><img src="assets/img/blog-details/blog-sm-1.jpg" alt=""></a>--}}
{{--                                        </div>--}}
{{--                                        <div class="rc__post-content">--}}
{{--                                            <div class="rc__meta">--}}
{{--                                                <span>4 March. 2022</span>--}}
{{--                                            </div>--}}
{{--                                            <h3 class="rc__post-title">--}}
{{--                                                <a href="blog-details.html">Don’t Underestimate The Software</a>--}}
{{--                                            </h3>--}}
{{--                                        </div>--}}
{{--                                    </div>--}}
{{--                                    <div class="rc__post mb-20 d-flex align-items-center">--}}
{{--                                        <div class="rc__post-thumb mr-20">--}}
{{--                                            <a href="blog-details.html"><img src="assets/img/blog-details/blog-sm-2.jpg" alt=""></a>--}}
{{--                                        </div>--}}
{{--                                        <div class="rc__post-content">--}}
{{--                                            <div class="rc__meta">--}}
{{--                                                <span>4 March. 2022</span>--}}
{{--                                            </div>--}}
{{--                                            <h3 class="rc__post-title">--}}
{{--                                                <a href="blog-details.html">Designing Human-Machine Interfaces..</a>--}}
{{--                                            </h3>--}}
{{--                                        </div>--}}
{{--                                    </div>--}}
{{--                                    <div class="rc__post mb-20 d-flex align-items-center">--}}
{{--                                        <div class="rc__post-thumb mr-20">--}}
{{--                                            <a href="blog-details.html"><img src="assets/img/blog-details/blog-sm-3.jpg" alt=""></a>--}}
{{--                                        </div>--}}
{{--                                        <div class="rc__post-content">--}}
{{--                                            <div class="rc__meta">--}}
{{--                                                <span>4 March. 2022</span>--}}
{{--                                            </div>--}}
{{--                                            <h3 class="rc__post-title">--}}
{{--                                                <a href="blog-details.html">Web Design Done Well: Excellent</a>--}}
{{--                                            </h3>--}}
{{--                                        </div>--}}
{{--                                    </div>--}}
{{--                                    <div class="rc__post mb-20 d-flex align-items-center">--}}
{{--                                        <div class="rc__post-thumb mr-20">--}}
{{--                                            <a href="blog-details.html"><img src="assets/img/blog-details/blog-sm-4.jpg" alt=""></a>--}}
{{--                                        </div>--}}
{{--                                        <div class="rc__post-content">--}}
{{--                                            <div class="rc__meta">--}}
{{--                                                <span>4 March. 2022</span>--}}
{{--                                            </div>--}}
{{--                                            <h3 class="rc__post-title">--}}
{{--                                                <a href="blog-details.html">Don’t Underestimate The Software </a>--}}
{{--                                            </h3>--}}
{{--                                        </div>--}}
{{--                                    </div>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                        <div class="sidebar__widget mb-40">--}}
{{--                            <h3 class="sidebar__widget-title">Tags</h3>--}}
{{--                            <div class="sidebar__widget-content">--}}
{{--                                <div class="tagcloud">--}}
{{--                                    <a href="blog.html">landing</a>--}}
{{--                                    <a href="blog.html">Charity</a>--}}
{{--                                    <a href="blog.html">apps</a>--}}
{{--                                    <a href="blog.html">Education </a>--}}
{{--                                    <a href="blog.html">data</a>--}}
{{--                                    <a href="blog.html">book</a>--}}
{{--                                    <a href="blog.html">Design</a>--}}
{{--                                    <a href="blog.html">website</a>--}}
{{--                                    <a href="blog.html">landing page</a>--}}
{{--                                    <a href="blog.html">data</a>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
            </div>
        </div>
    </div>
    <!-- postbox area end -->
@endsection
